$(document).ready(function() {
    $('#lista').DataTable( {
        "language": {
            "lengthMenu": "Listar _MENU_ por pagina",
            "zeroRecords": "Nothing found - sorry",
            "info": "Mostrando pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtered from _MAX_ total records)"
        }
    } );
} );