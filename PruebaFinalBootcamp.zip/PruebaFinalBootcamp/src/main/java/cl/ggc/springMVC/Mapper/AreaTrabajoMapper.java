/**
 * 
 */
package cl.ggc.springMVC.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import cl.ggc.springMVC.model.AreaTrabajo;

/**
 * @author HP
 *
 */
public class AreaTrabajoMapper implements RowMapper<AreaTrabajo> {

	@Override
	public AreaTrabajo mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		return new AreaTrabajo(rs.getInt("idArea"),rs.getNString("nombreArea"));
	}
	
	
	
	
	

}
