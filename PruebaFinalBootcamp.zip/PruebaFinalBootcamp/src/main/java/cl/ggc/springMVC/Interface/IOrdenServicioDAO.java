/**
 * 
 */
package cl.ggc.springMVC.Interface;


import java.util.List;

import cl.ggc.springMVC.model.OrdenServicio;

/**
 * @author HP
 *
 */
public interface IOrdenServicioDAO {
	
	
	public boolean crearOrdenServicio(OrdenServicio ordenServicio); 
	public List<OrdenServicio> listaOrdenServicio(); 
	public boolean reagendarOrdenServicio(int id,OrdenServicio ordenServicio);
	public OrdenServicio listarId(int id);	
	public boolean eliminarOrden(int id);	
		
	
	

}
