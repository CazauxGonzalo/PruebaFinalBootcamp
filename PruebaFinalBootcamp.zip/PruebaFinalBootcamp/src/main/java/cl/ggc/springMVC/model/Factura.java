package cl.ggc.springMVC.model;

import java.sql.Date;

public class Factura {
	
	private int idFactura;
	private Date fechaFactura;
	/**
	 * @param idFactura
	 * @param fechaFactura
	 */
	public Factura(int idFactura, Date fechaFactura) {
		super();
		this.idFactura = idFactura;
		this.fechaFactura = fechaFactura;
	}
	/**
	 * @return the idFactura
	 */
	public int getIdFactura() {
		return idFactura;
	}
	/**
	 * @param idFactura the idFactura to set
	 */
	public void setIdFactura(int idFactura) {
		this.idFactura = idFactura;
	}
	/**
	 * @return the fechaFactura
	 */
	public Date getFechaFactura() {
		return fechaFactura;
	}
	/**
	 * @param fechaFactura the fechaFactura to set
	 */
	public void setFechaFactura(Date fechaFactura) {
		this.fechaFactura = fechaFactura;
	}
	

	
	
}
