package cl.ggc.springMVC.model;

public class Region {
	
	private int idRegion;
	private String nombreRegion;
	
	
	
	
	
	/**
	 * 
	 */
	public Region() {
		super();
	}
	/**
	 * @param idRegion
	 * @param nombreRegion
	 */
	public Region(int idRegion, String nombreRegion) {
		super();
		this.idRegion = idRegion;
		this.nombreRegion = nombreRegion;
	}
	/**
	 * @return the idRegion
	 */
	public int getIdRegion() {
		return idRegion;
	}
	/**
	 * @param idRegion the idRegion to set
	 */
	public void setIdRegion(int idRegion) {
		this.idRegion = idRegion;
	}
	/**
	 * @return the nombreRegion
	 */
	public String getNombreRegion() {
		return nombreRegion;
	}
	/**
	 * @param nombreRegion the nombreRegion to set
	 */
	public void setNombreRegion(String nombreRegion) {
		this.nombreRegion = nombreRegion;
	}
	
	
	
	
		
	
}
