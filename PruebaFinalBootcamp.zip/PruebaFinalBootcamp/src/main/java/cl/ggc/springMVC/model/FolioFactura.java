/**
 * 
 */
package cl.ggc.springMVC.model;

/**
 * @author HP
 *
 */
public class FolioFactura {
	
	
	private int idFolio;
	private int numFolio;
	private int estadoFolio;
	/**
	 * @param idFolio
	 * @param numFolio
	 * @param estadoFolio
	 */
	public FolioFactura(int idFolio, int numFolio, int estadoFolio) {
		super();
		this.idFolio = idFolio;
		this.numFolio = numFolio;
		this.estadoFolio = estadoFolio;
	}
	/**
	 * @return the idFolio
	 */
	public int getIdFolio() {
		return idFolio;
	}
	/**
	 * @param idFolio the idFolio to set
	 */
	public void setIdFolio(int idFolio) {
		this.idFolio = idFolio;
	}
	/**
	 * @return the numFolio
	 */
	public int getNumFolio() {
		return numFolio;
	}
	/**
	 * @param numFolio the numFolio to set
	 */
	public void setNumFolio(int numFolio) {
		this.numFolio = numFolio;
	}
	/**
	 * @return the estadoFolio
	 */
	public int getEstadoFolio() {
		return estadoFolio;
	}
	/**
	 * @param estadoFolio the estadoFolio to set
	 */
	public void setEstadoFolio(int estadoFolio) {
		this.estadoFolio = estadoFolio;
	}
	
	
	

}
