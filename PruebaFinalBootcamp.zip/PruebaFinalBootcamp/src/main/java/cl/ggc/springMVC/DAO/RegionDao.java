/**
 * 
 */
package cl.ggc.springMVC.DAO;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import cl.ggc.springMVC.Interface.IRegionDAO;
import cl.ggc.springMVC.Mapper.RegionMapper;
import cl.ggc.springMVC.model.Region;

/**
 * @author HP
 *
 */
public class RegionDao implements IRegionDAO {
	
JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public List<Region> listaRegion() {
		String sql = "select idregion, nombreregion from region order by nombreregion asc";
		
		return template.query(sql, new RegionMapper());
	}
	

	

}
