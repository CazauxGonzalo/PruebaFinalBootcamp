/**
 * 
 */
package cl.ggc.springMVC.DAO;


import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;



import cl.ggc.springMVC.Interface.IEmpleadoDAO;
import cl.ggc.springMVC.Mapper.EmpleadoMapper;
import cl.ggc.springMVC.model.Empleado;

/**
 * @author HP
 *
 */
public class EmpleadoDao implements IEmpleadoDAO {
	
JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public boolean actualizarMisDatos(String rut) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Empleado listarId(int id) {
		String sql = "select idempleado, rutempleado, nombreempleado, apellidoempleado, mailempleado, fonoempleado, claveempleado, direccionempleado, cargo_idcargo, comuna_idcomuna  " + "from Empleado where idempleado = ?";
		
		return template.queryForObject(sql, new Object[] {id}, new EmpleadoMapper());
	}

	@Override
	public List<Empleado> listaEmpleados() {
		String sql = "select idempleado, rutempleado, nombreempleado, apellidoempleado, mailempleado, fonoempleado, claveempleado, direccionempleado, cargo_idcargo, comuna_idcomuna  " + "from Empleado order by idempleado asc";
		
		return template.query(sql, new EmpleadoMapper());
	}
	
	

	@Override
	public boolean crearEmpleado(Empleado employed) {
		String sql = "INSERT INTO empleado VALUES(idempleado.nextval,'"+ employed.getRutEmpleado()  +"','"+ employed.getNombreEmpleado() +"','"+ employed.getApellidoEmpleado() +"','"+ employed.getMailEmpleado() +"','"+ employed.getFonoEmpleado() +"',"+ "NULL" +",'"+ employed.getDireccionEmpleado() +"','"+ employed.getCargo() +"','"+ employed.getComuna() +"')";
		
		template.execute(sql);	
		
		return true;
	}

	@Override
	public boolean actualizarEmpleado(int idEmpleado,Empleado employed) {
		String sql = "UPDATE empleado SET rutempleado = '"+ employed.getRutEmpleado() +"', nombreempleado ='"+ employed.getNombreEmpleado() +"', apellidoempleado='"+ employed.getApellidoEmpleado() +"', mailempleado ='"+ employed.getMailEmpleado() +"', fonoempleado ='"+ employed.getFonoEmpleado() +"', direccionempleado ='"+ employed.getDireccionEmpleado() +"', cargo_idcargo ='"+ employed.getCargo() +"', comuna_idcomuna ='"+ employed.getComuna() +"' where idempleado =" + idEmpleado;
		
		template.update(sql);
		
		return true;
	}

	@Override
	public boolean eliminarEmpleado(int idEmpleado) {
		String sql = "DELETE from empleado where idempleado =" + idEmpleado;
		
		template.execute(sql);
		return true;
	}
	
	
	
}
