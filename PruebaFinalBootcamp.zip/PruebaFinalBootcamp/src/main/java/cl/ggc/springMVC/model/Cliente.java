package cl.ggc.springMVC.model;

public class Cliente {
	
   private int idCliente;
   private String nombreCliente;
   private String rutCliente;
   private String direccionCliente;
   private int idcomuna;
/**
 * @param idCliente
 * @param nombreCliente
 * @param rutCliente
 * @param direccionCliente
 * @param idcomuna
 */
   
   
   
public Cliente(int idCliente, String nombreCliente, String rutCliente, String direccionCliente, int idcomuna) {
	super();
	this.idCliente = idCliente;
	this.nombreCliente = nombreCliente;
	this.rutCliente = rutCliente;
	this.direccionCliente = direccionCliente;
	this.idcomuna = idcomuna;
}
/**
 * @param nombreCliente
 * @param rutCliente
 * @param direccionCliente
 * @param idcomuna
 */
public Cliente(String nombreCliente, String rutCliente, String direccionCliente, int idcomuna) {
	super();
	this.nombreCliente = nombreCliente;
	this.rutCliente = rutCliente;
	this.direccionCliente = direccionCliente;
	this.idcomuna = idcomuna;
}
/**
 * 
 */
public Cliente() {
	super();
}
/**
 * @return the idCliente
 */
public int getIdCliente() {
	return idCliente;
}
/**
 * @param idCliente the idCliente to set
 */
public void setIdCliente(int idCliente) {
	this.idCliente = idCliente;
}
/**
 * @return the nombreCliente
 */
public String getNombreCliente() {
	return nombreCliente;
}
/**
 * @param nombreCliente the nombreCliente to set
 */
public void setNombreCliente(String nombreCliente) {
	this.nombreCliente = nombreCliente;
}
/**
 * @return the rutCliente
 */
public String getRutCliente() {
	return rutCliente;
}
/**
 * @param rutCliente the rutCliente to set
 */
public void setRutCliente(String rutCliente) {
	this.rutCliente = rutCliente;
}
/**
 * @return the direccionCliente
 */
public String getDireccionCliente() {
	return direccionCliente;
}
/**
 * @param direccionCliente the direccionCliente to set
 */
public void setDireccionCliente(String direccionCliente) {
	this.direccionCliente = direccionCliente;
}
/**
 * @return the idcomuna
 */
public int getIdcomuna() {
	return idcomuna;
}
/**
 * @param idcomuna the idcomuna to set
 */
public void setIdcomuna(int idcomuna) {
	this.idcomuna = idcomuna;
}
   
   
   
   
   
}