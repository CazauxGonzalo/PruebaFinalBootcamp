/**
 * 
 */
package cl.ggc.springMVC.Interface;

import java.util.List;

import cl.ggc.springMVC.model.AreaTrabajo;

/**
 * @author HP
 *
 */
public interface IAreaTrabajoDAO  {
	
	public List<AreaTrabajo> listaArea();
	
	

}
