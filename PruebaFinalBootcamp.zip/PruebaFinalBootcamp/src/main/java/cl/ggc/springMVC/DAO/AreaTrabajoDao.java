/**
 * 
 */
package cl.ggc.springMVC.DAO;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import cl.ggc.springMVC.Interface.IAreaTrabajoDAO;

import cl.ggc.springMVC.Mapper.AreaTrabajoMapper;
import cl.ggc.springMVC.model.AreaTrabajo;


/**
 * @author HP
 *
 */
public class AreaTrabajoDao implements IAreaTrabajoDAO  {
	
JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public List<AreaTrabajo> listaArea() {
		String sql = "select idarea, nombrearea from areatrabajo order by nombrearea asc";
		return template.query(sql, new AreaTrabajoMapper());
	}

	
}
