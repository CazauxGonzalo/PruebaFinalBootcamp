package cl.ggc.springMVC.Interface;

import java.util.List;

import cl.ggc.springMVC.model.Empleado;

public interface IEmpleadoDAO {
	
	public boolean actualizarMisDatos(String rut);
	public Empleado listarId(int id);
	public List<Empleado> listaEmpleados();
	public boolean crearEmpleado(Empleado employed);
	public boolean actualizarEmpleado(int idEmpleado, Empleado employed);
	public boolean eliminarEmpleado (int idEmpleado);	
	
}
