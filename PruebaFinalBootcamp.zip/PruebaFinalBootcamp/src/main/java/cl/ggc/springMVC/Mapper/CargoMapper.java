/**
 * 
 */
package cl.ggc.springMVC.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import cl.ggc.springMVC.model.Cargo;

/**
 * @author HP
 *
 */
public class CargoMapper implements RowMapper<Cargo>{

	@Override
	public Cargo mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		return new Cargo(rs.getInt("idCargo"), rs.getNString("nombreCargo"));
	}

}
