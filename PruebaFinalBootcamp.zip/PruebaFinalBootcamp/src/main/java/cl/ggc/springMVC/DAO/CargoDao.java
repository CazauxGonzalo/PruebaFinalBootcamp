/**
 * 
 */
package cl.ggc.springMVC.DAO;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import cl.ggc.springMVC.Interface.ICargoDAO;
import cl.ggc.springMVC.Mapper.CargoMapper;
import cl.ggc.springMVC.model.Cargo;

/**
 * @author HP
 *
 */
public class CargoDao implements ICargoDAO {

JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public List<Cargo> listaCargo() {
		String sql = "select idcargo, nombrecargo from cargo order by nombrecargo asc";
		return template.query(sql, new CargoMapper());
	}
	

	
}
