package cl.ggc.springMVC.model;

public class Empleado  {
	
	private int idEmpleado;
	private String rutEmpleado;
	private String nombreEmpleado;
	private String apellidoEmpleado;
	private String mailEmpleado;
	private String fonoEmpleado;
	private String claveEmpleado;
	private String direccionEmpleado;
	private int cargo;
	private int comuna;
	/**
	 * 
	 */
	public Empleado() {
		super();
	}
	/**
	 * @param idEmpleado
	 * @param rutEmpleado
	 * @param nombreEmpleado
	 * @param apellidoEmpleado
	 * @param mailEmpleado
	 * @param fonoEmpleado
	 * @param claveEmpleado
	 * @param direccionEmpleado
	 * @param cargo
	 * @param comuna
	 */
	public Empleado(int idEmpleado, String rutEmpleado, String nombreEmpleado, String apellidoEmpleado,
			String mailEmpleado, String fonoEmpleado, String claveEmpleado, String direccionEmpleado, int cargo,
			int comuna) {
		super();
		this.idEmpleado = idEmpleado;
		this.rutEmpleado = rutEmpleado;
		this.nombreEmpleado = nombreEmpleado;
		this.apellidoEmpleado = apellidoEmpleado;
		this.mailEmpleado = mailEmpleado;
		this.fonoEmpleado = fonoEmpleado;
		this.claveEmpleado = claveEmpleado;
		this.direccionEmpleado = direccionEmpleado;
		this.cargo = cargo;
		this.comuna = comuna;
	}
	
	
	
	/**
	 * @param idEmpleado
	 * @param rutEmpleado
	 * @param nombreEmpleado
	 * @param apellidoEmpleado
	 * @param mailEmpleado
	 * @param fonoEmpleado
	 * @param claveEmpleado
	 * @param direccionEmpleado
	 */
	public Empleado(int idEmpleado, String rutEmpleado, String nombreEmpleado, String apellidoEmpleado,
			String mailEmpleado, String fonoEmpleado, String claveEmpleado, String direccionEmpleado) {
		super();
		this.idEmpleado = idEmpleado;
		this.rutEmpleado = rutEmpleado;
		this.nombreEmpleado = nombreEmpleado;
		this.apellidoEmpleado = apellidoEmpleado;
		this.mailEmpleado = mailEmpleado;
		this.fonoEmpleado = fonoEmpleado;
		this.claveEmpleado = claveEmpleado;
		this.direccionEmpleado = direccionEmpleado;
	}
	/**
	 * @return the idEmpleado
	 */
	public int getIdEmpleado() {
		return idEmpleado;
	}
	/**
	 * @param idEmpleado the idEmpleado to set
	 */
	public void setIdEmpleado(int idEmpleado) {
		this.idEmpleado = idEmpleado;
	}
	/**
	 * @return the rutEmpleado
	 */
	public String getRutEmpleado() {
		return rutEmpleado;
	}
	/**
	 * @param rutEmpleado the rutEmpleado to set
	 */
	public void setRutEmpleado(String rutEmpleado) {
		this.rutEmpleado = rutEmpleado;
	}
	/**
	 * @return the nombreEmpleado
	 */
	public String getNombreEmpleado() {
		return nombreEmpleado;
	}
	/**
	 * @param nombreEmpleado the nombreEmpleado to set
	 */
	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}
	/**
	 * @return the apellidoEmpleado
	 */
	public String getApellidoEmpleado() {
		return apellidoEmpleado;
	}
	/**
	 * @param apellidoEmpleado the apellidoEmpleado to set
	 */
	public void setApellidoEmpleado(String apellidoEmpleado) {
		this.apellidoEmpleado = apellidoEmpleado;
	}
	/**
	 * @return the mailEmpleado
	 */
	public String getMailEmpleado() {
		return mailEmpleado;
	}
	/**
	 * @param mailEmpleado the mailEmpleado to set
	 */
	public void setMailEmpleado(String mailEmpleado) {
		this.mailEmpleado = mailEmpleado;
	}
	/**
	 * @return the fonoEmpleado
	 */
	public String getFonoEmpleado() {
		return fonoEmpleado;
	}
	/**
	 * @param fonoEmpleado the fonoEmpleado to set
	 */
	public void setFonoEmpleado(String fonoEmpleado) {
		this.fonoEmpleado = fonoEmpleado;
	}
	/**
	 * @return the claveEmpleado
	 */
	public String getClaveEmpleado() {
		return claveEmpleado;
	}
	/**
	 * @param claveEmpleado the claveEmpleado to set
	 */
	public void setClaveEmpleado(String claveEmpleado) {
		this.claveEmpleado = claveEmpleado;
	}
	/**
	 * @return the direccionEmpleado
	 */
	public String getDireccionEmpleado() {
		return direccionEmpleado;
	}
	/**
	 * @param direccionEmpleado the direccionEmpleado to set
	 */
	public void setDireccionEmpleado(String direccionEmpleado) {
		this.direccionEmpleado = direccionEmpleado;
	}
	/**
	 * @return the cargo
	 */
	public int getCargo() {
		return cargo;
	}
	/**
	 * @param cargo the cargo to set
	 */
	public void setCargo(int cargo) {
		this.cargo = cargo;
	}
	/**
	 * @return the comuna
	 */
	public int getComuna() {
		return comuna;
	}
	/**
	 * @param comuna the comuna to set
	 */
	public void setComuna(int comuna) {
		this.comuna = comuna;
	}
	
	
		

}
