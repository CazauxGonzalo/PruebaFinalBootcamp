/**
 * 
 */
package cl.ggc.springMVC.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import cl.ggc.springMVC.model.Empleado;

/**
 * @author HP
 *
 */
public class EmpleadoMapper implements RowMapper<Empleado>{	
	
	public Empleado mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Empleado(rs.getInt("idEmpleado"), rs.getString("rutEmpleado"), rs.getString("nombreEmpleado"), rs.getString("apellidoEmpleado"), rs.getString("mailEmpleado"), rs.getString("fonoEmpleado"), rs.getString("claveEmpleado"), rs.getString("direccionEmpleado"),rs.getInt("cargo_idcargo"),rs.getInt("comuna_idcomuna"));
	}

}
