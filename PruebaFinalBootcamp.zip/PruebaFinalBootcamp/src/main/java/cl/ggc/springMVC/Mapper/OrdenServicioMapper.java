/**
 * 
 */
package cl.ggc.springMVC.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import cl.ggc.springMVC.model.OrdenServicio;

/**
 * @author HP
 *
 */
public class OrdenServicioMapper implements RowMapper<OrdenServicio> {

	@Override
	public OrdenServicio mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		return new OrdenServicio(rs.getInt("idOrden"), rs.getNString("fechaOrden"), rs.getNString("fechaCita"), rs.getNString("direccionServicio"), rs.getInt("comuna_idcomuna"), rs.getInt("cliente_idcliente"), rs.getInt("horario_idhorario"), rs.getInt("empleado_idempleado"), rs.getInt("estadoorden_idestado"));
	}
	
	
	

}
