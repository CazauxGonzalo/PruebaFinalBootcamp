/**
 * 
 */
package cl.ggc.springMVC.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import cl.ggc.springMVC.model.Cliente;



/**
 * @author HP
 *
 */
public class ClienteMapper implements RowMapper<Cliente> {
	
	public Cliente mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Cliente(rs.getInt("idCliente"), rs.getString("nombreCliente"), rs.getString("rutCliente"), rs.getString("direccionCliente"), rs.getInt("comuna_idcomuna"));
	}
	
	

}
