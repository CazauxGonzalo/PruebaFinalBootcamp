/**
 * 
 */
package cl.ggc.springMVC.DAO;


import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import cl.ggc.springMVC.Interface.IOrdenServicioDAO;

import cl.ggc.springMVC.Mapper.OrdenServicioMapper;
import cl.ggc.springMVC.model.OrdenServicio;

/**
 * @author HP
 *
 */
public class OrdenServicioDao implements IOrdenServicioDAO {
	
JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;				
		
	}
	
	
	/**
	 *
	 */
	@Override
	public boolean crearOrdenServicio(OrdenServicio ordenServicio) {
            String sql = "INSERT INTO ordenservicio VALUES(idorden.nextval,'"+ ordenServicio.getFechaOrden()  +"','"+ ordenServicio.getFechaCita() +"','"+ ordenServicio.getDireccionServicio() +"','"+ ordenServicio.getComuna() +"','"+ ordenServicio.getCliente() +"','"+ ordenServicio.getHorario() +"','"+ ordenServicio.getEmpleado() +"','"+ ordenServicio.getEstado() +"')";
		
		template.execute(sql);	
		return true;
	}

	@Override
	public List<OrdenServicio> listaOrdenServicio() {
		
             String sql = "select idorden, fechaorden, fechacita, direccionservicio, comuna_idcomuna, cliente_idcliente, horario_idhorario, empleado_idempleado, estadoorden_idestado " + "from ordenservicio order by idorden asc";
		
		return template.query(sql, new OrdenServicioMapper());
		
		
		
	}

	@Override
	public boolean reagendarOrdenServicio(int id, OrdenServicio ordenServicio) {
		String sql = "UPDATE ordenservicio SET fechacita = TO_DATE('"+ ordenServicio.getFechaCita()  +"','YYYY-MM-DD'), direccionservicio ='"+ ordenServicio.getDireccionServicio() +"', comuna_idcomuna ='"+ ordenServicio.getComuna() +"', horario_idhorario ='"+ ordenServicio.getHorario() +"', empleado_idempleado ='"+ ordenServicio.getEmpleado()+"' where idorden ='"+ id +"' ";
		
		template.update(sql);
		return true;
	}


	@Override
	public OrdenServicio listarId(int id) {
              String sql = "select idorden, fechaorden, fechacita, direccionservicio, comuna_idcomuna, cliente_idcliente, horario_idhorario, empleado_idempleado, estadoorden_idestado " + "from ordenservicio where idorden= ?";
		
		return template.queryForObject(sql, new Object[] {id}, new OrdenServicioMapper());
		
		
	}


	@Override
	public boolean eliminarOrden(int id) {
		String sql = "UPDATE ordenservicio SET estadoorden_idestado ='3' where idorden='" + id +"' ";
		
		template.update(sql);
		
		return true;
	}
	


}
