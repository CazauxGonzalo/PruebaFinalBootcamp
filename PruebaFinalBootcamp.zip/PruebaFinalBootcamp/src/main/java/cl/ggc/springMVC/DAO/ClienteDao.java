/**
 * 
 */
package cl.ggc.springMVC.DAO;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import cl.ggc.springMVC.Interface.IClienteDAO;
import cl.ggc.springMVC.Mapper.ClienteMapper;
import cl.ggc.springMVC.model.Cliente;

/**
 * @author HP
 *
 */
public class ClienteDao implements IClienteDAO{
	
	
JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public boolean crearCliente(Cliente customer) {
              String sql = "INSERT INTO cliente VALUES(idcliente.nextval,'"+ customer.getNombreCliente()  +"','"+ customer.getRutCliente() +"','"+ customer.getDireccionCliente() +"','"+ customer.getIdcomuna() +"')";
		
		template.execute(sql);	
		
		return true;
	}

	@Override
	public List<Cliente> listarCustumer() {
		String sql = "select idcliente, nombrecliente, rutcliente, direccioncliente, comuna_idcomuna " + "from Cliente order by idcliente asc";
		
		return template.query(sql, new ClienteMapper());
	}

	@Override
	public boolean actualizarCliente(int id,Cliente customer) {
		String sql = "UPDATE cliente SET nombrecliente='"+ customer.getNombreCliente()  +"', rutcliente ='"+ customer.getRutCliente() +"', direccioncliente ='"+ customer.getDireccionCliente() +"', comuna_idcomuna ='"+ customer.getIdcomuna()+"' where idcliente ='" + id +"' ";
		
		template.update(sql);
		
		return true;
	}

	@Override
	public Cliente listarId(int id) {
            String sql = "select idcliente, nombrecliente, rutcliente, direccioncliente, comuna_idcomuna " + "from Cliente where idcliente = ?";
		
		return template.queryForObject(sql, new Object[] {id}, new ClienteMapper());
	}

	@Override
	public boolean borrarCliente(int id) {
		String sql = "DELETE from cliente where idcliente =" + id ;
		template.execute(sql);
		return true;
	}
	


}
