/**
 * 
 */
package cl.ggc.springMVC.DAO;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import cl.ggc.springMVC.Interface.IComunaDAO;
import cl.ggc.springMVC.Mapper.ComunaMapper;
import cl.ggc.springMVC.model.Comuna;

/**
 * @author HP
 *
 */
public class ComunaDao implements IComunaDAO {
	
JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public List<Comuna> listaComuna() {
		String sql = "select idcomuna, nombrecomuna from comuna order by nombrecomuna asc";
		return template.query(sql, new ComunaMapper());
	}
	

	

}
