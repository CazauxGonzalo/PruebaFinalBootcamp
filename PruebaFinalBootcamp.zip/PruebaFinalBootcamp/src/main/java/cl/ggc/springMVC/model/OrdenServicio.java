package cl.ggc.springMVC.model;



public class OrdenServicio {

	private int idOrden;
	private String fechaOrden;
	private String fechaCita;
	private String direccionServicio;
	private int comuna;
	private int cliente;
	private int horario;
	private int empleado;
	private int estado;
	/**
	 * 
	 */
	public OrdenServicio() {
		super();
	}
	/**
	 * @param idOrden
	 * @param fechaOrden
	 * @param fechaCita
	 * @param direccionServicio
	 * @param comuna
	 * @param cliente
	 * @param horario
	 * @param empleado
	 * @param estado
	 */
	public OrdenServicio(int idOrden, String fechaOrden, String fechaCita, String direccionServicio, int comuna,
			int cliente, int horario, int empleado, int estado) {
		super();
		this.idOrden = idOrden;
		this.fechaOrden = fechaOrden;
		this.fechaCita = fechaCita;
		this.direccionServicio = direccionServicio;
		this.comuna = comuna;
		this.cliente = cliente;
		this.horario = horario;
		this.empleado = empleado;
		this.estado = estado;
	}
	
	
	
	
	/**
	 * @param idOrden
	 * @param fechaCita
	 * @param direccionServicio
	 * @param comuna
	 * @param horario
	 * @param empleado
	 */
	public OrdenServicio(int idOrden, String fechaCita, String direccionServicio, int comuna, int horario,
			int empleado) {
		super();
		this.idOrden = idOrden;
		this.fechaCita = fechaCita;
		this.direccionServicio = direccionServicio;
		this.comuna = comuna;
		this.horario = horario;
		this.empleado = empleado;
	}
	/**
	 * @return the idOrden
	 */
	public int getIdOrden() {
		return idOrden;
	}
	/**
	 * @param idOrden the idOrden to set
	 */
	public void setIdOrden(int idOrden) {
		this.idOrden = idOrden;
	}
	/**
	 * @return the fechaOrden
	 */
	public String getFechaOrden() {
		return fechaOrden;
	}
	/**
	 * @param fechaOrden the fechaOrden to set
	 */
	public void setFechaOrden(String fechaOrden) {
		this.fechaOrden = fechaOrden;
	}
	/**
	 * @return the fechaCita
	 */
	public String getFechaCita() {
		return fechaCita;
	}
	/**
	 * @param fechaCita the fechaCita to set
	 */
	public void setFechaCita(String fechaCita) {
		this.fechaCita = fechaCita;
	}
	/**
	 * @return the direccionServicio
	 */
	public String getDireccionServicio() {
		return direccionServicio;
	}
	/**
	 * @param direccionServicio the direccionServicio to set
	 */
	public void setDireccionServicio(String direccionServicio) {
		this.direccionServicio = direccionServicio;
	}
	/**
	 * @return the comuna
	 */
	public int getComuna() {
		return comuna;
	}
	/**
	 * @param comuna the comuna to set
	 */
	public void setComuna(int comuna) {
		this.comuna = comuna;
	}
	/**
	 * @return the cliente
	 */
	public int getCliente() {
		return cliente;
	}
	/**
	 * @param cliente the cliente to set
	 */
	public void setCliente(int cliente) {
		this.cliente = cliente;
	}
	/**
	 * @return the horario
	 */
	public int getHorario() {
		return horario;
	}
	/**
	 * @param horario the horario to set
	 */
	public void setHorario(int horario) {
		this.horario = horario;
	}
	/**
	 * @return the empleado
	 */
	public int getEmpleado() {
		return empleado;
	}
	/**
	 * @param empleado the empleado to set
	 */
	public void setEmpleado(int empleado) {
		this.empleado = empleado;
	}
	/**
	 * @return the estado
	 */
	public int getEstado() {
		return estado;
	}
	/**
	 * @param estado the estado to set
	 */
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	
	
	
	
}
