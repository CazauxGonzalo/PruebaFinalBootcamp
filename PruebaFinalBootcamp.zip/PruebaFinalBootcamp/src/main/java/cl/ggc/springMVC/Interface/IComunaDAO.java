/**
 * 
 */
package cl.ggc.springMVC.Interface;

import java.util.List;

import cl.ggc.springMVC.model.Comuna;

/**
 * @author HP
 *
 */
public interface IComunaDAO {
	
	
	public List<Comuna> listaComuna();

}
