package cl.ggc.springMVC.model;

public class DetServicio {
	
	private int idDetalle;

	/**
	 * @param idDetalle
	 */
	public DetServicio(int idDetalle) {
		super();
		this.idDetalle = idDetalle;
	}

	/**
	 * @return the idDetalle
	 */
	public int getIdDetalle() {
		return idDetalle;
	}

	/**
	 * @param idDetalle the idDetalle to set
	 */
	public void setIdDetalle(int idDetalle) {
		this.idDetalle = idDetalle;
	}
	
	
	
	

}
