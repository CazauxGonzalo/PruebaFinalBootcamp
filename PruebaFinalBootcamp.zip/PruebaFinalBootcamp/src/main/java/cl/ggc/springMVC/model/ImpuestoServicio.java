package cl.ggc.springMVC.model;

public class ImpuestoServicio {
	
	private int idImpto;
	private String nombreImpto;
	private float tasaImpto;
	/**
	 * @param idImpto
	 * @param nombreImpto
	 * @param tasaImpto
	 */
	public ImpuestoServicio(int idImpto, String nombreImpto, float tasaImpto) {
		super();
		this.idImpto = idImpto;
		this.nombreImpto = nombreImpto;
		this.tasaImpto = tasaImpto;
	}
	/**
	 * @return the idImpto
	 */
	public int getIdImpto() {
		return idImpto;
	}
	/**
	 * @param idImpto the idImpto to set
	 */
	public void setIdImpto(int idImpto) {
		this.idImpto = idImpto;
	}
	/**
	 * @return the nombreImpto
	 */
	public String getNombreImpto() {
		return nombreImpto;
	}
	/**
	 * @param nombreImpto the nombreImpto to set
	 */
	public void setNombreImpto(String nombreImpto) {
		this.nombreImpto = nombreImpto;
	}
	/**
	 * @return the tasaImpto
	 */
	public float getTasaImpto() {
		return tasaImpto;
	}
	/**
	 * @param tasaImpto the tasaImpto to set
	 */
	public void setTasaImpto(float tasaImpto) {
		this.tasaImpto = tasaImpto;
	}
	
		
	
	
}
