package cl.ggc.springMVC.model;

public class ContactoCliente {
	
	private int idContacto;
	private String nombreContacto;
	private String mailContacto;
	private String fonoContacto;
	private String cargoContacto;
	/**
	 * @param idContacto
	 * @param nombreContacto
	 * @param mailContacto
	 * @param fonoContacto
	 * @param cargoContacto
	 */
	public ContactoCliente(int idContacto, String nombreContacto, String mailContacto, String fonoContacto,
			String cargoContacto) {
		super();
		this.idContacto = idContacto;
		this.nombreContacto = nombreContacto;
		this.mailContacto = mailContacto;
		this.fonoContacto = fonoContacto;
		this.cargoContacto = cargoContacto;
	}
	/**
	 * @return the idContacto
	 */
	public int getIdContacto() {
		return idContacto;
	}
	/**
	 * @param idContacto the idContacto to set
	 */
	public void setIdContacto(int idContacto) {
		this.idContacto = idContacto;
	}
	/**
	 * @return the nombreContacto
	 */
	public String getNombreContacto() {
		return nombreContacto;
	}
	/**
	 * @param nombreContacto the nombreContacto to set
	 */
	public void setNombreContacto(String nombreContacto) {
		this.nombreContacto = nombreContacto;
	}
	/**
	 * @return the mailContacto
	 */
	public String getMailContacto() {
		return mailContacto;
	}
	/**
	 * @param mailContacto the mailContacto to set
	 */
	public void setMailContacto(String mailContacto) {
		this.mailContacto = mailContacto;
	}
	/**
	 * @return the fonoContacto
	 */
	public String getFonoContacto() {
		return fonoContacto;
	}
	/**
	 * @param fonoContacto the fonoContacto to set
	 */
	public void setFonoContacto(String fonoContacto) {
		this.fonoContacto = fonoContacto;
	}
	/**
	 * @return the cargoContacto
	 */
	public String getCargoContacto() {
		return cargoContacto;
	}
	/**
	 * @param cargoContacto the cargoContacto to set
	 */
	public void setCargoContacto(String cargoContacto) {
		this.cargoContacto = cargoContacto;
	}
	
	
	
	
}