/**
 * 
 */
package cl.ggc.springMVC.Interface;

import java.util.List;

import cl.ggc.springMVC.model.Region;

/**
 * @author HP
 *
 */
public interface IRegionDAO {
	
	public List<Region> listaRegion();
	
	
	

}
