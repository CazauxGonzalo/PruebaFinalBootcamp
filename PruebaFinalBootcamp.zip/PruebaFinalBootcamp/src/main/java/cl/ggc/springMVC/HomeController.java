package cl.ggc.springMVC;



import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
		
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		
		
		return "Index";
	}
	
	@RequestMapping(value = "/Ingreso", method = RequestMethod.GET)
	public String ingreso() {
		
		
		return "NavAdm";
	}
	
	
	/*
	@RequestMapping(value = "/NavAdm", method = RequestMethod.GET)
	public String NavAdm() {
		
		
		return "NavAdm";
	}
	
    @RequestMapping("/login")
    public String login()
    {
    	System.out.println(SecurityContextHolder.getContext().getAuthentication().getName());
        return "login";
    }
    
    @RequestMapping("/logout")
    public String logout()
    {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){    
        	SecurityContextHolder.getContext().setAuthentication(null);
        }
        return "redirect:/login";
    }

	@RequestMapping("/error")
    public String error(ModelMap model)
    {
		System.out.println("ERROR!");
        model.addAttribute("error", "true");
        return "login";

    }
	*/
	
	
	
	
	
	
}
