package cl.ggc.springMVC.model;

public class Cargo  {
	
	private int idCargo;
	private String nombreCargo;
	
	
	
	
	/**
	 * 
	 */
	public Cargo() {
		super();
	}
	/**
	 * @param idCargo
	 * @param nombreCargo
	 */
	public Cargo(int idCargo, String nombreCargo) {
		super();
		this.idCargo = idCargo;
		this.nombreCargo = nombreCargo;
	}
	/**
	 * @return the idCargo
	 */
	public int getIdCargo() {
		return idCargo;
	}
	/**
	 * @param idCargo the idCargo to set
	 */
	public void setIdCargo(int idCargo) {
		this.idCargo = idCargo;
	}
	/**
	 * @return the nombreCargo
	 */
	public String getNombreCargo() {
		return nombreCargo;
	}
	/**
	 * @param nombreCargo the nombreCargo to set
	 */
	public void setNombreCargo(String nombreCargo) {
		this.nombreCargo = nombreCargo;
	}
	


}
