package cl.ggc.springMVC.model;

public class Horario {
	
	private int idHorario;
	private String nombreHorario;
	/**
	 * @param idHorario
	 * @param nombreHorario
	 */
	public Horario(int idHorario, String nombreHorario) {
		super();
		this.idHorario = idHorario;
		this.nombreHorario = nombreHorario;
	}
	/**
	 * @return the idHorario
	 */
	public int getIdHorario() {
		return idHorario;
	}
	/**
	 * @param idHorario the idHorario to set
	 */
	public void setIdHorario(int idHorario) {
		this.idHorario = idHorario;
	}
	/**
	 * @return the nombreHorario
	 */
	public String getNombreHorario() {
		return nombreHorario;
	}
	/**
	 * @param nombreHorario the nombreHorario to set
	 */
	public void setNombreHorario(String nombreHorario) {
		this.nombreHorario = nombreHorario;
	}
	
	
	

}
