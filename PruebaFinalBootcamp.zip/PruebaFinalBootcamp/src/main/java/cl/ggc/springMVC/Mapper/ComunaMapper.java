/**
 * 
 */
package cl.ggc.springMVC.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import cl.ggc.springMVC.model.Comuna;

/**
 * @author HP
 *
 */
public class ComunaMapper implements RowMapper<Comuna> {

	@Override
	public Comuna mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		return new Comuna(rs.getInt("idComuna"), rs.getNString("nombreComuna"));
	}
	
	
	

}
