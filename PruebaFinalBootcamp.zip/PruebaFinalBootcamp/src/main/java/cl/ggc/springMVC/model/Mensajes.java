/**
 * 
 */
package cl.ggc.springMVC.model;

import java.sql.Date;

/**
 * @author HP
 *
 */
public class Mensajes {
	
	private int idMensaje;
	private String mensaje;
	private String leido;
	private Date fechaMEnsaje;
	/**
	 * @param idMensaje
	 * @param mensaje
	 * @param leido
	 * @param fechaMEnsaje
	 */
	public Mensajes(int idMensaje, String mensaje, String leido, Date fechaMEnsaje) {
		super();
		this.idMensaje = idMensaje;
		this.mensaje = mensaje;
		this.leido = leido;
		this.fechaMEnsaje = fechaMEnsaje;
	}
	/**
	 * @return the idMensaje
	 */
	public int getIdMensaje() {
		return idMensaje;
	}
	/**
	 * @param idMensaje the idMensaje to set
	 */
	public void setIdMensaje(int idMensaje) {
		this.idMensaje = idMensaje;
	}
	/**
	 * @return the mensaje
	 */
	public String getMensaje() {
		return mensaje;
	}
	/**
	 * @param mensaje the mensaje to set
	 */
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	/**
	 * @return the leido
	 */
	public String getLeido() {
		return leido;
	}
	/**
	 * @param leido the leido to set
	 */
	public void setLeido(String leido) {
		this.leido = leido;
	}
	/**
	 * @return the fechaMEnsaje
	 */
	public Date getFechaMEnsaje() {
		return fechaMEnsaje;
	}
	/**
	 * @param fechaMEnsaje the fechaMEnsaje to set
	 */
	public void setFechaMEnsaje(Date fechaMEnsaje) {
		this.fechaMEnsaje = fechaMEnsaje;
	}
	
	
	
	
	

}
