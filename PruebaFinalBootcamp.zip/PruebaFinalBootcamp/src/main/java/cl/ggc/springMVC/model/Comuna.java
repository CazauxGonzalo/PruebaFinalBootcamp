package cl.ggc.springMVC.model;

public class Comuna {
	
	
	private int idComuna;
	private String nombreComuna;
	
	
	
	
	/**
	 * 
	 */
	public Comuna() {
		super();
	}
	/**
	 * @param idComuna
	 * @param nombreComuna
	 */
	public Comuna(int idComuna, String nombreComuna) {
		super();
		this.idComuna = idComuna;
		this.nombreComuna = nombreComuna;
	}
	/**
	 * @return the idComuna
	 */
	public int getIdComuna() {
		return idComuna;
	}
	/**
	 * @param idComuna the idComuna to set
	 */
	public void setIdComuna(int idComuna) {
		this.idComuna = idComuna;
	}
	/**
	 * @return the nombreComuna
	 */
	public String getNombreComuna() {
		return nombreComuna;
	}
	/**
	 * @param nombreComuna the nombreComuna to set
	 */
	public void setNombreComuna(String nombreComuna) {
		this.nombreComuna = nombreComuna;
	}
	
	
	
	

}
