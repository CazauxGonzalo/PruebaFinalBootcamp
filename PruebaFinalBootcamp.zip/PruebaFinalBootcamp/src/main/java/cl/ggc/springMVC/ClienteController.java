/**
 * 
 */
package cl.ggc.springMVC;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.servlet.ModelAndView;

import cl.ggc.springMVC.DAO.ClienteDao;
import cl.ggc.springMVC.DAO.ComunaDao;
import cl.ggc.springMVC.DAO.RegionDao;
import cl.ggc.springMVC.model.Cliente;
import cl.ggc.springMVC.model.Comuna;
import cl.ggc.springMVC.model.Region;




/**
 * @author HP
 *
 */
@Controller
public class ClienteController {
	
	
	@Autowired
	ClienteDao dao;
	@Autowired
	RegionDao daoRegion;
	@Autowired
	ComunaDao daoComuna;
	
	@RequestMapping(value="/maestroCliente", method=RequestMethod.GET)
	public String maestroCliente() {
		return "MaestroCliente";
				
	}
	
	@RequestMapping(value="/editarCliente/{id}", method=RequestMethod.GET)
	public ModelAndView editarCliente(@PathVariable int id) {
		
		Cliente c = dao.listarId(id);		
		
		return new ModelAndView("EditarCliente","customer",c);		
		
	}
	
	
	@RequestMapping(value="/editarCliente/{id}", method=RequestMethod.POST)
   	public String editarCliente(HttpServletRequest request, Model model,@PathVariable int id) { 
    	
    	ApplicationContext ac = new ClassPathXmlApplicationContext("cl/ggc/springMVC/config/beans.xml");
       	    	
    	Cliente c = (Cliente) ac.getBean("cliente");
    	
    	c.setNombreCliente(request.getParameter("nombreCliente"));
    	c.setRutCliente(request.getParameter("rutCliente"));
    	c.setDireccionCliente(request.getParameter("direccionCliente"));    	
    	c.setIdcomuna(Integer.parseInt(request.getParameter("comunaCliente")));
    	
    	boolean ingresar = dao.actualizarCliente(id, c);
    	String vista;
    	
    	((AbstractApplicationContext)ac).close();
    	
    	if (ingresar) {
    	 vista = "Confirmacion";	
    		
		}else {
			vista = "error";
		}
    	
		
		return vista;
    	
   		
       }
	
	
	@RequestMapping(value="/ListadoCliente", method=RequestMethod.GET)
	public ModelAndView listaClientes() {
    	
    	List<Cliente> lista =  dao.listarCustumer();
    	
		return new ModelAndView("ListadoCliente", "lista", lista) ;		
			
	}
	
	
	
	@RequestMapping(value="/CrearCliente", method=RequestMethod.GET)
	public ModelAndView CrearCliente() { 
		
		
		List<Region> listaRegion = daoRegion.listaRegion();
    	List<Comuna> listaComuna = daoComuna.listaComuna();
    	
    	ModelAndView modelAndView = new ModelAndView("CrearCliente");
    	
    	
    	modelAndView.addObject("listaRegion",listaRegion);
    	modelAndView.addObject("listaComuna", listaComuna);
    	
		return modelAndView;	
    	    	
		
    }
	
	
	@RequestMapping(value="/CrearCliente", method=RequestMethod.POST)
   	public String AgregarCliente(HttpServletRequest request, Model model) { 
    	
    	ApplicationContext ac = new ClassPathXmlApplicationContext("cl/ggc/springMVC/config/beans.xml");
       	    	
    	Cliente c = (Cliente) ac.getBean("cliente");
    	
    	
    	c.setNombreCliente(request.getParameter("nombreCliente"));
    	c.setRutCliente(request.getParameter("rutCliente"));
    	c.setDireccionCliente(request.getParameter("direccionCliente"));    	
    	c.setIdcomuna(Integer.parseInt(request.getParameter("comunaCliente")));
    	
    	
    	boolean ingresar = dao.crearCliente(c);
    	String vista;
    	
    	((AbstractApplicationContext)ac).close();
    	
    	if (ingresar) {
    	 vista = "Confirmacion";	
    		
		}else {
			vista = "error";
		}
    	
		
		return vista;
    	
   		
       }
	
	/*
    @RequestMapping(value="/CrearCliente", method=RequestMethod.POST)
   	public @ResponseBody Cliente AgregarCliente(@RequestBody Cliente c) { 
    
    
    	dao.crearCliente(c);
    	
    	return c;
    	
   		
       }*/
    
    
    
    @RequestMapping(value="/borrarCliente/{id}", method=RequestMethod.GET)
    public String eliminarCliente(@PathVariable int id) {
   	
   	boolean ingresar = dao.borrarCliente(id); 
   	String vista;
   	
   	if (ingresar) {
   	 vista = "Confirmacion";	
   		
		}else {
			vista = "error";
		}
   	
   	
   	return vista ;
   	
   	
   } 
	

}
