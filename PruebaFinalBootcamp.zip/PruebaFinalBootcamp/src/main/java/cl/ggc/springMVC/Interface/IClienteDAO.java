/**
 * 
 */
package cl.ggc.springMVC.Interface;

import java.util.List;

import cl.ggc.springMVC.model.Cliente;


/**
 * @author HP
 *
 */
public interface IClienteDAO {
	
	public boolean crearCliente(Cliente customer);
	public List<Cliente> listarCustumer();
	public boolean actualizarCliente(int id,Cliente customer);
	public  Cliente listarId(int id);
	public boolean borrarCliente(int id);
	
	
	

}
