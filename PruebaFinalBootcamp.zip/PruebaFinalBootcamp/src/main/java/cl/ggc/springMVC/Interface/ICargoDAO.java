/**
 * 
 */
package cl.ggc.springMVC.Interface;

import java.util.List;

import cl.ggc.springMVC.model.Cargo;

/**
 * @author HP
 *
 */
public interface ICargoDAO {
	
	
	public List<Cargo> listaCargo();
	

}
