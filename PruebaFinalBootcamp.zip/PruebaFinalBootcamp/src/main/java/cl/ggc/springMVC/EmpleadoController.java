/**
 * 
 */
package cl.ggc.springMVC;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import cl.ggc.springMVC.DAO.AreaTrabajoDao;
import cl.ggc.springMVC.DAO.CargoDao;
import cl.ggc.springMVC.DAO.ComunaDao;
import cl.ggc.springMVC.DAO.EmpleadoDao;
import cl.ggc.springMVC.DAO.RegionDao;
import cl.ggc.springMVC.model.AreaTrabajo;
import cl.ggc.springMVC.model.Cargo;
import cl.ggc.springMVC.model.Comuna;
import cl.ggc.springMVC.model.Empleado;
import cl.ggc.springMVC.model.Region;

/**
 * @author HP
 *
 */
@Controller
public class EmpleadoController {
	
	@Autowired
	EmpleadoDao dao;
	@Autowired
	AreaTrabajoDao daoArea;
	@Autowired
	CargoDao daoCargo;
	@Autowired
	RegionDao daoRegion;
	@Autowired
	ComunaDao daoComuna;
	
	@RequestMapping(value="/maestroEmpleado", method=RequestMethod.GET)
	public String maestroEmpleado() {
		
		return "MaestroEmpleado";		
		
	}
	
    @RequestMapping(value="/ListadoEmpleado", method=RequestMethod.GET)
	public ModelAndView listaEmpleados() {
    	
    	List<Empleado> lista =  dao.listaEmpleados();
    	
    	
    	
		return new ModelAndView("ListadoEmpleado", "lista", lista) ;		
			
	}
    
    @RequestMapping(value="/CrearEmpleado", method=RequestMethod.GET)
	public ModelAndView CrearEmpleado() { 
    	
    	List<AreaTrabajo> listaAreaTrabajo = daoArea.listaArea();
    	List<Cargo> listaCargo = daoCargo.listaCargo();
    	List<Region> listaRegion = daoRegion.listaRegion();
    	List<Comuna> listaComuna = daoComuna.listaComuna();
    	
    	ModelAndView modelAndView = new ModelAndView("CrearEmpleado");
    	
    	modelAndView.addObject("listaCargo",listaCargo);    
    	modelAndView.addObject("listaArea",listaAreaTrabajo);
    	modelAndView.addObject("listaRegion",listaRegion);
    	modelAndView.addObject("listaComuna", listaComuna);
    	
		return modelAndView;	
		
    }
	
    @RequestMapping(value="/CrearEmpleado", method=RequestMethod.POST)
   	public String AgregarEmpleado(HttpServletRequest request, Model model) { 
    	//SecurityContextHolder.getContext().getAuthentication().getName();
    	ApplicationContext ac = new ClassPathXmlApplicationContext("cl/ggc/springMVC/config/beans.xml");
       	    	
    	Empleado e = (Empleado) ac.getBean("empleado");
    	
    	e.setRutEmpleado(request.getParameter("rutEmpleado"));
    	e.setNombreEmpleado(request.getParameter("nombreEmpleado"));
    	e.setApellidoEmpleado(request.getParameter("apellidoEmpleado"));    	
    	e.setMailEmpleado(request.getParameter("mailEmpleado"));
    	e.setFonoEmpleado(request.getParameter("fonoEmpleado"));
    	e.setDireccionEmpleado(request.getParameter("direccionEmpleado"));
    	e.setCargo(Integer.parseInt(request.getParameter("cargoEmpleado")));
    	e.setComuna(Integer.parseInt(request.getParameter("comunaEmpleado")));
    	
    	boolean ingresar = dao.crearEmpleado(e);
    	String vista;
    	
    	((AbstractApplicationContext)ac).close();
    	
    	if (ingresar) {
    	 vista = "Confirmacion";	
    		
		}else {
			vista = "error";
		}
    	
		
		return vista;
    	
   		
       }
   	
    
    @RequestMapping(value="/editarEmpleado/{id}", method=RequestMethod.GET)
    public ModelAndView editarEmpleado(@PathVariable int id) {
		
    	Empleado e = dao.listarId(id);
    	
    	List<AreaTrabajo> listaAreaTrabajo = daoArea.listaArea();
    	List<Cargo> listaCargo = daoCargo.listaCargo();
    	List<Region> listaRegion = daoRegion.listaRegion();
    	List<Comuna> listaComuna = daoComuna.listaComuna();
    	
    	ModelAndView modelAndView = new ModelAndView("EditarEmpleado");
    	
    	modelAndView.addObject("employed",e);   
    	modelAndView.addObject("listaCargo",listaCargo);    
    	modelAndView.addObject("listaArea",listaAreaTrabajo);
    	modelAndView.addObject("listaRegion",listaRegion);
    	modelAndView.addObject("listaComuna", listaComuna);
    	
		return modelAndView;	
    	
    	
    	
		
    	    	
    }
    
   
    @RequestMapping(value="/editarEmpleado/{id}", method=RequestMethod.POST)
   	public String editarEmpleado(HttpServletRequest request, Model model,@PathVariable int id) { 
    	
    	ApplicationContext ac = new ClassPathXmlApplicationContext("cl/ggc/springMVC/config/beans.xml");
       	    	
    	Empleado e = (Empleado) ac.getBean("empleado");
    	
    	e.setRutEmpleado(request.getParameter("rutEmpleado"));
    	e.setNombreEmpleado(request.getParameter("nombreEmpleado"));
    	e.setApellidoEmpleado(request.getParameter("apellidoEmpleado"));    	
    	e.setMailEmpleado(request.getParameter("mailEmpleado"));
    	e.setFonoEmpleado(request.getParameter("fonoEmpleado"));
    	e.setDireccionEmpleado(request.getParameter("direccionEmpleado"));
    	e.setCargo(Integer.parseInt(request.getParameter("cargoEmpleado")));
    	e.setComuna(Integer.parseInt(request.getParameter("comunaEmpleado")));
    	
    	boolean ingresar = dao.actualizarEmpleado(id,e);
    	String vista;
    	
    	((AbstractApplicationContext)ac).close();
    	
    	if (ingresar) {
    	 vista = "Confirmacion";	
    		
		}else {
			vista = "error";
		}
    	
		
		return vista;
    	
   		
       }
    
    @RequestMapping(value="/borrarEmpleado/{id}", method=RequestMethod.GET)
     public String eliminarEmpleado(@PathVariable int id) {
    	
    	boolean ingresar = dao.eliminarEmpleado(id);    	 	
    	String vista;
    	if (ingresar) {
       	 vista = "Confirmacion";	
       		
   		}else {
   			vista = "error";
   		}
       	
   		
   		return vista;
    	
    	
    } 
    
    
}
