/**
 * 
 */
package cl.ggc.springMVC;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import cl.ggc.springMVC.DAO.OrdenServicioDao;

import cl.ggc.springMVC.model.OrdenServicio;


/**
 * @author HP
 *
 */

@Controller
public class OrdenServicioController {

	@Autowired
	OrdenServicioDao dao;
	
	
	@RequestMapping(value="/maestroOrdenServicio", method=RequestMethod.GET)
	public String maestroOrdenServicio() {
		return "MaestroOrdenServicio";
				
	}
	
	@RequestMapping(value="/CrearOrdenServicio", method=RequestMethod.GET)
	public String CrearOrdenServicio() {    	
    	    	
		return "CrearOrdenServicio";	
    }
	
	
	
	 @RequestMapping(value="/CrearOrdenServicio", method=RequestMethod.POST)
	   	public String AgregarOrdenServicio(HttpServletRequest request, Model model) { 
	    	
	    	ApplicationContext ac = new ClassPathXmlApplicationContext("cl/ggc/springMVC/config/beans.xml");
	       	    	
	    	OrdenServicio os = (OrdenServicio) ac.getBean("ordenServicio");
	    	
	    		
	    	os.setFechaOrden(request.getParameter("fechaOrden"));
	    	os.setFechaCita(request.getParameter("fechaCita"));
	    	os.setDireccionServicio(request.getParameter("direccionServicio"));
	    	os.setComuna(Integer.parseInt(request.getParameter("comunaServicio")));	    	
	    	os.setCliente(Integer.parseInt(request.getParameter("clienteServicio")));	    	
	    	os.setHorario(Integer.parseInt(request.getParameter("horarioServicio")));
	    	os.setEmpleado(Integer.parseInt(request.getParameter("empleadoServicio"))); 
	    	os.setEstado(Integer.parseInt(request.getParameter("estadoOrden")));
	    	
	    	  	
	    	
	    	boolean ingresar = dao.crearOrdenServicio(os);
	    	String vista;
	    	
	    	((AbstractApplicationContext)ac).close();
	    	
	    	if (ingresar) {
	    	 vista = "Confirmacion";	
	    		
			}else {
				vista = "error";
			}	    	
			
			return vista;
	    		   		
	       }
	
	
	 @RequestMapping(value="/ListadoOrdenServicio", method=RequestMethod.GET)
		public ModelAndView listaOrdenServicio() {
	    	
	    	List<OrdenServicio> lista =  dao.listaOrdenServicio();
	    	
			return new ModelAndView("ListadoOrdenServicio", "lista", lista) ;		
				
		}
	 
	 @RequestMapping(value="/editarOrdenServicio/{id}", method=RequestMethod.GET)
		public ModelAndView editarOrdenServicio(@PathVariable int id) {
			
			OrdenServicio os = dao.listarId(id);		
			
			return new ModelAndView("EditarOrdenServicio","ordenServicio",os);		
			
		}
	 
	 @RequestMapping(value="/editarOrdenServicio/{id}", method=RequestMethod.POST)
	 public String modificarOrdenServicio(HttpServletRequest request, Model model, @PathVariable int id) {
		 
		 ApplicationContext ac = new ClassPathXmlApplicationContext("cl/ggc/springMVC/config/beans.xml");
	    	
	    	OrdenServicio os = (OrdenServicio) ac.getBean("ordenServicio");
	    	
	    	
	    	os.setFechaCita(request.getParameter("fechaCita"));
	    	os.setDireccionServicio(request.getParameter("direccionServicio"));
	    	os.setComuna(Integer.parseInt(request.getParameter("comunaServicio"))); 
	    	os.setHorario(Integer.parseInt(request.getParameter("horarioServicio")));
	    	os.setEmpleado(Integer.parseInt(request.getParameter("empleadoServicio"))); 
	    	
		   boolean ingresar = dao.reagendarOrdenServicio(id,os);
		 
		    
             String vista;
	    	
	    	((AbstractApplicationContext)ac).close();
	    	
	    	if (ingresar) {
	    	 vista = "Confirmacion";	
	    		
			}else {
				vista = "error";
			}	    	
			
			return vista;   
		
	 }
	 
	 @RequestMapping(value="/eliminarOrden/{id}", method=RequestMethod.GET)
	 public String eliminarOrden(@PathVariable int id) {
		 
		 boolean ingresar = dao.eliminarOrden(id);
		 
		 String vista;
		 
		 if (ingresar) {
	    	 vista = "Confirmacion";	
	    		
			}else {
				vista = "error";
			}	    	
			
			return vista;
		 
		 
		 
	 }
	 
	 
	 
}
