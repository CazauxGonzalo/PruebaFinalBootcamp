package cl.ggc.springMVC.model;

public class AreaTrabajo {
	
	private int idArea;
	private String nombreArea;
	
	
	
	
	/**
	 * 
	 */
	public AreaTrabajo() {
		super();
	}

	/**
	 * @param idArea
	 * @param nombreArea
	 */
	public AreaTrabajo(int idArea, String nombreArea) {
		super();
		this.idArea = idArea;
		this.nombreArea = nombreArea;
	}

	/**
	 * @return the idArea
	 */
	public int getIdArea() {
		return idArea;
	}

	/**
	 * @param idArea the idArea to set
	 */
	public void setIdArea(int idArea) {
		this.idArea = idArea;
	}

	/**
	 * @return the nombreArea
	 */
	public String getNombreArea() {
		return nombreArea;
	}

	/**
	 * @param nombreArea the nombreArea to set
	 */
	public void setNombreArea(String nombreArea) {
		this.nombreArea = nombreArea;
	}
	
	
	

}
