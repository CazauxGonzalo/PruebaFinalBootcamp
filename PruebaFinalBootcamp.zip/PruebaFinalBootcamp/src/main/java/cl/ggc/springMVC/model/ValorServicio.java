package cl.ggc.springMVC.model;

import java.sql.Date;

public class ValorServicio {
	
	private int idValorServicio;
	private Date fechaValor;
	private int montoServicio;
	/**
	 * @param idValorServicio
	 * @param fechaValor
	 * @param montoServicio
	 */
	public ValorServicio(int idValorServicio, Date fechaValor, int montoServicio) {
		super();
		this.idValorServicio = idValorServicio;
		this.fechaValor = fechaValor;
		this.montoServicio = montoServicio;
	}
	/**
	 * @return the idValorServicio
	 */
	public int getIdValorServicio() {
		return idValorServicio;
	}
	/**
	 * @param idValorServicio the idValorServicio to set
	 */
	public void setIdValorServicio(int idValorServicio) {
		this.idValorServicio = idValorServicio;
	}
	/**
	 * @return the fechaValor
	 */
	public Date getFechaValor() {
		return fechaValor;
	}
	/**
	 * @param fechaValor the fechaValor to set
	 */
	public void setFechaValor(Date fechaValor) {
		this.fechaValor = fechaValor;
	}
	/**
	 * @return the montoServicio
	 */
	public int getMontoServicio() {
		return montoServicio;
	}
	/**
	 * @param montoServicio the montoServicio to set
	 */
	public void setMontoServicio(int montoServicio) {
		this.montoServicio = montoServicio;
	}
	
	
	
	
	

}
