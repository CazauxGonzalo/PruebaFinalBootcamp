package cl.ggc.springMVC.model;

public class Servicio {
	
	private int idServicio;
	private String nombreServicio;
	/**
	 * @param idServicio
	 * @param nombreServicio
	 */
	public Servicio(int idServicio, String nombreServicio) {
		super();
		this.idServicio = idServicio;
		this.nombreServicio = nombreServicio;
	}
	/**
	 * @return the idServicio
	 */
	public int getIdServicio() {
		return idServicio;
	}
	/**
	 * @param idServicio the idServicio to set
	 */
	public void setIdServicio(int idServicio) {
		this.idServicio = idServicio;
	}
	/**
	 * @return the nombreServicio
	 */
	public String getNombreServicio() {
		return nombreServicio;
	}
	/**
	 * @param nombreServicio the nombreServicio to set
	 */
	public void setNombreServicio(String nombreServicio) {
		this.nombreServicio = nombreServicio;
	}

	
	
	

}
